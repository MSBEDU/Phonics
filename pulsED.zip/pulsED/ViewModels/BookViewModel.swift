import SwiftUI
import Combine

class BookViewModel: ObservableObject {
    @Published var books: [Book] = []

    init() {
        loadBooks()
    }

    func loadBooks() {
        let fileManager = FileManager.default
        if let path = Bundle.main.resourcePath?.appending("/Books") {
            do {
                let files = try fileManager.contentsOfDirectory(atPath: path)
                for file in files {
                    if file.hasSuffix(".json") {
                        if let url = Bundle.main.url(forResource: "Books/\(file)", withExtension: nil) {
                            let data = try Data(contentsOf: url)
                            let book = try JSONDecoder().decode(Book.self, from: data)
                            books.append(book)
                        }
                    }
                }
            } catch {
                print("Error loading books: \(error.localizedDescription)")
            }
        }
    }
}


