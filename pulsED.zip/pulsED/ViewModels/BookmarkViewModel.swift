import SwiftUI
import Combine
import Foundation


class BookmarkViewModel: ObservableObject {
    @Published var bookmarkedBooks: [Book] = []
    @Published var progresses: [UUID: Double] = [:]

    func addBookmark(book: Book) {
        if !bookmarkedBooks.contains(where: { $0.id == book.id }) {
            bookmarkedBooks.append(book)
        }
    }

    func removeBookmark(book: Book) {
        if let index = bookmarkedBooks.firstIndex(where: { $0.id == book.id }) {
            bookmarkedBooks.remove(at: index)
        }
    }

    func updateProgress(for book: Book, progress: Double) {
        progresses[book.id] = progress
    }
}
