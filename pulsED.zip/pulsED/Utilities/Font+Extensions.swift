//
//  Font+Extensions.swift
//  pulsED
//
//  Created by Michael Bailey on 28/05/2024.
//

import Foundation
import SwiftUI

extension Font {
    static func inter(size: CGFloat) -> Font {
        return Font.custom("Inter-Regular", size: size)
    }

    static func interBold(size: CGFloat) -> Font {
        return Font.custom("Inter-Bold", size: size)
    }

    static func interItalic(size: CGFloat) -> Font {
        return Font.custom("Inter-Italic", size: size)
    }
}
