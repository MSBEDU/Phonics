
import Foundation
import SwiftUI
import Combine

import SwiftUI

struct Book: Identifiable, Codable, Hashable {
    var id: UUID
    var title: String
    var author: String
    var description: String
    var imageName: String
    var genres: [String]
    var progress: Double
    var content: [BookContent]
}

struct BookContent: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var content: String
}
