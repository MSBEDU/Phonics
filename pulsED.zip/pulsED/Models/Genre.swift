//
//  Genre.swift
//  pulsED
//
//  Created by Michael Bailey on 28/05/2024.
//
import SwiftUI
import Combine
import Foundation

import Foundation
import Foundation

struct Genre: Identifiable, Codable {
    var id: UUID
    let name: String
    var books: [UUID]
}
