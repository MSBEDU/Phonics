import SwiftUI
import Combine
import Foundation

import Foundation

struct User: Identifiable, Codable {
    var id: UUID
    let username: String
    let email: String
    var bookmarks: [UUID]
}
