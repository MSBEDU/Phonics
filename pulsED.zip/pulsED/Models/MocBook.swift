import SwiftUI
import Combine
import Foundation

struct MocBook {
    static let mockBooks: [Book] = [
        Book(
            id: UUID(),
            title: "How Children Succeed: Grit, Curiosity, and the Hidden Power of Character",
            author: "Paul Tough",
            description: "A book that investigates the factors that contribute to a child's success, emphasizing the importance of character.",
            imageName: "PaulTough",
            genres: ["Character Education", "Motivation"],
            progress: 0.8,
            content: [
                BookContent(title: "Character trumps Cognitive Skills", content: """
                In "How Children Succeed," Paul Tough emphasizes that character plays a significant role and character traits like grit and perseverance are imperative for success, sometimes more than even cognitive skills and intelligence. Grit is known as the sustaining effort and the passion that needs to be shown for long-term goals even after falling down or facing adversities. This has been popularized by the psychologist Angela Duckworth. Tough mentions that curiosity and optimism are other things that play a significant role in making a person explore and learn proactively.
                """),
                BookContent(title: "Role of Adversity", content: """
                Tough discusses how early childhood adversity, namely poverty and neglect, can harmfully affect brain development, stress responses, and consequently have problematic effects on emotional and cognitive functions of the child. Still, children can be made resilient if they have the right support and interventions. This support includes supportive relationships, positive school environments, and programs that teach coping skills. That's the work, as Tough describes it, of researchers like Jack Shonkoff, who study how toxic stress has lifelong effects and how supportive interventions for such kids can diminish these effects to make the children succeed despite the early hardships.
                """),
                BookContent(title: "Importance of Relationships", content: """
                Children get all the necessary grounds for emotional and social interactions in this world from their parents, teachers, and other mentors in their lives. Tough says that these kinds of relationships are the only things that have the capacity to buffer the ill effects that stress has on children's minds. He uses attachment theory, developed by John Bowlby and Mary Ainsworth, which has said that secure attachments in early childhood result in better emotional regulation and social skills. Tough gives specific examples of mentoring programs and interventions that build on these attachments, showing that such attachments are essential in guiding children to success.
                """),
                BookContent(title: "Non-Cognitive Skills in School", content: """
                Tough points out several school-based interventions or programs that target these non-cognitive skills, including self-control, social intelligence, and gratitude, in addition to those concerned with academic skills. Programs like the KIPP (Knowledge Is Power Program) schools and Tools of the Mind focus on students' character and executive function skills. The programs help students acquire and master the non-cognitive skills that enable them to excel in both academic and life situations. Tough claims that such character education increases the school performance levels of students because non-cognitive skills are the essential ingredients in handling all of life's difficulties.
                """),
                BookContent(title: "Evidence and Research", content: """
                Paul Tough uses an enormous amount of research in psychology, neuroscience, and education to back his claims. He relies on the work of such researchers as Angela Duckworth, who studies grit; James Heckman, an economist who shows the relevance of non-cognitive skills in economic success; and Jack Shonkoff, who examines the effects of early adversity on child development. The studies collectively suggest that character can be produced and that character produces long term success. Tough himself gives much evidence in the form of case studies of students who have overcome much through character development, showing the power of the production of character in becoming successful.
                """),
                BookContent(title: "Conclusion", content: """
                Paul Tough, in "How Children Succeed", moves from traditional indicators of academic success to those of character that impact children and determine the outcome of life's trials. To learn more about Tough's work, which focuses on grit, curiosity, and supportive relationships, read his book: a comprehensive view of what goes to the very core of a child's success. A road map to shaping educational programs and support systems to develop those all-important non-cognitive skills, which allow kids to achieve the great things against all the odds. Read more about these findings in the book, which is available at Amazon.
                """)
            ]
        ),
        Book(
            id: UUID(),
            title: "Visible Learning: A Synthesis of Over 800 Meta-Analyses Relating to Achievement",
            author: "John Hattie",
            description: "A book that synthesizes educational research to identify the most effective teaching strategies.",
            imageName: "JHvisiblelearning",
            genres: ["Educational Research", "Teaching Strategies"],
            progress: 0.6,
            content: [
                BookContent(title: "Introduction and the Visible Learning Story", content: """
                John Hattie's "Visible Learning" begins by introducing the concept of visible learning, which focuses on evidence-based teaching strategies. Hattie synthesizes over 800 meta-analyses related to student achievement, emphasizing the importance of using evidence to guide educational practices. Teachers are encouraged to reflect on their methods and engage in professional development to stay informed about the latest research-based strategies.
                """),
                BookContent(title: "The Source of the Ideas", content: """
                Hattie outlines the sources and methods used in his research, stressing the significance of meta-analyses in understanding what works in education. He advocates for utilizing educational research databases to find relevant studies and collaborating with colleagues to discuss and implement these findings. This approach helps educators make informed decisions about their teaching practices.
                """),
                BookContent(title: "The Power of Feedback", content: """
                Feedback is a critical component of effective teaching, according to Hattie. He highlights that feedback should be timely, specific, and constructive to significantly impact student achievement. Teachers should provide regular, detailed feedback and encourage students to give peer feedback and reflect on the input they receive. This process helps students understand their progress and areas for improvement.
                """),
                BookContent(title: "The Role of the Teacher", content: """
                Teachers play a crucial role in influencing student achievement. Hattie identifies characteristics of effective teachers, such as clarity, passion, and the ability to create a positive learning environment. Educators are advised to be explicit about learning objectives and success criteria, and to foster a supportive and engaging classroom atmosphere. These practices enhance students' learning experiences and outcomes.
                """),
                BookContent(title: "The Importance of Learning Intentions and Success Criteria", content: """
                Setting clear learning intentions and success criteria is essential for guiding student learning. Hattie emphasizes that students should understand what they are expected to learn and how they will be assessed. Teachers should articulate learning goals at the beginning of each lesson and use success criteria to help students self-assess and peer-assess their work, promoting a deeper understanding of their learning objectives.
                """),
                BookContent(title: "The Influence of Direct Instruction", content: """
                Direct instruction, when done effectively, is a highly impactful teaching method. Hattie explains that this approach involves clear teaching of skills and knowledge in a structured manner. Teachers should plan lessons that include explicit teaching, modeling, and guided practice, ensuring students understand the purpose and relevance of each lesson. This method helps students grasp complex concepts more effectively.
                """),
                BookContent(title: "The Impact of Differentiated Instruction", content: """
                Differentiated instruction tailors teaching to meet the diverse needs of students. Hattie stresses the importance of knowing your students well and using assessment data to inform instructional planning. By providing varied learning activities that cater to different learning styles and abilities, teachers can help all students succeed. This personalized approach ensures that each student receives the support they need.
                """),
                BookContent(title: "The Role of Assessment", content: """
                Effective assessment informs teaching and tracks student progress. Hattie discusses the use of both formative and summative assessments. Formative assessments should be used regularly to check for understanding and adjust teaching accordingly, while summative assessments should accurately reflect student learning. This balanced approach helps educators support student growth and achievement.
                """),
                BookContent(title: "The Influence of the Home", content: """
                Hattie acknowledges the significant impact of parental involvement and the home environment on student achievement. Regular communication with parents about their child's progress and encouraging parental support for learning at home can enhance student outcomes. Strong home-school partnerships contribute to a more holistic approach to education.
                """),
                BookContent(title: "The Power of Expectations", content: """
                High expectations from teachers can lead to higher student achievement. Hattie explains the Pygmalion effect, where higher expectations result in improved performance. Teachers should set high but achievable expectations for all students and communicate their belief in students' abilities to succeed. This positive reinforcement can motivate students to strive for excellence.
                """),
                BookContent(title: "The Impact of Peer Influences", content: """
                Peer interactions can significantly affect learning. Hattie discusses strategies to foster positive peer influences, such as collaborative learning activities and teaching students how to give constructive feedback. By promoting a supportive peer culture, teachers can enhance students' social and academic development.
                """),
                BookContent(title: "The Role of School Leadership", content: """
                Effective school leadership is vital for creating a supportive environment that promotes student learning. Hattie emphasizes the importance of instructional leadership, where school leaders focus on supporting teachers' professional growth and fostering a culture of continuous improvement. Positive school leadership can lead to better teaching practices and student outcomes.
                """),
                BookContent(title: "The Impact of School Climate", content: """
                A positive school climate enhances student learning and well-being. Hattie identifies key factors that contribute to a positive climate, such as safety, inclusiveness, and strong relationships between students, teachers, and staff. Schools should promote a supportive environment where all members feel valued and respected, leading to improved student engagement and success.
                """)
            ]
        )
        // Add other books as needed
    ]
}

