//
//  BookmarkManager.swift
//  pulsED
//
//  Created by Michael Bailey on 30/05/2024.
//

import Foundation
import SwiftUI

class BookmarkManager: ObservableObject {
    @Published var bookmarks: [Book: Double] = [:]
    
    func updateProgress(for book: Book, progress: Double) {
        bookmarks[book] = progress
    }
}
