import SwiftUI

struct HomeView: View {
    @EnvironmentObject var bookViewModel: BookViewModel

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Continue Reading")) {
                    ForEach(bookViewModel.books) { book in
                        NavigationLink(destination: BookDetailView(book: book)) {
                            Text(book.title)
                        }
                    }
                }
                Section(header: Text("Featured")) {
                    ForEach(bookViewModel.books) { book in
                        NavigationLink(destination: BookDetailView(book: book)) {
                            Text(book.title)
                        }
                    }
                }
                Section(header: Text("Recommended by Teachers")) {
                    ForEach(bookViewModel.books) { book in
                        NavigationLink(destination: BookDetailView(book: book)) {
                            Text(book.title)
                        }
                    }
                }
            }
            .navigationBarTitle("pulsED")
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(BookViewModel())
    }
}

