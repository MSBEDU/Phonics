import SwiftUI

struct ModulesView: View {
    let modules = [
        "Module 1: Effective Classroom Management",
        "Module 2: Understanding Student Behavior",
        "Module 3: Engaging Teaching Strategies",
        "Module 4: Differentiated Instruction",
        "Module 5: Formative Assessment Techniques",
        "Module 6: Integrating Technology in the Classroom"
    ]
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Text("Modules")
                    .font(.largeTitle)
                    .foregroundColor(.blue)
                    .padding(.top, 20)
                    .padding(.leading, 16)
                
                ScrollView {
                    LazyVStack(spacing: 20) {
                        ForEach(modules, id: \.self) { module in
                            ModuleCard(module: module)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .background(Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all))
            .navigationBarTitle("Modules", displayMode: .inline)
        }
    }
}

struct ModuleCard: View {
    let module: String
    
    var body: some View {
        Text(module)
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.blue)
            .cornerRadius(10)
            .shadow(radius: 5)
    }
}

struct ModulesView_Previews: PreviewProvider {
    static var previews: some View {
        ModulesView()
    }
}

