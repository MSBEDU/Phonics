import SwiftUI
import Combine
import Foundation

import SwiftUI

struct BookmarkedView: View {
    var body: some View {
        Text("Bookmarked View")
            .font(.largeTitle)
            .padding()
    }
}

struct BookmarkedView_Previews: PreviewProvider {
    static var previews: some View {
        BookmarkedView()
    }
}
