//
//  SearchView.swift
//  pulsED
//
//  Created by Michael Bailey on 28/05/2024.
//

import Foundation
import SwiftUI

struct SearchView: View {
    @State private var searchText = ""

    var body: some View {
        VStack {
            HStack {
                TextField("Search...", text: $searchText)
                    .padding(8)
                    .background(Color.white)
                    .cornerRadius(8)
                Button(action: {
                    // Action for search button
                }) {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.softGrey)
                        .padding()
                }
            }
            .padding()
            .background(Color.skyblue)
            .padding(.horizontal, 16)
            .padding(.top, 16)

            List {
                // Populate search results here
            }
            .listStyle(PlainListStyle())
        }
        .navigationBarTitle("Search", displayMode: .inline)
    }
}
