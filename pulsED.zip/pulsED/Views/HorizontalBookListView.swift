import SwiftUI
import Combine
import Foundation

import SwiftUI

struct HorizontalBookListView: View {
    let books: [Book]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 16) {
                ForEach(books) { book in
                    NavigationLink(destination: BookDetailView(book: book)) {
                        BookCard(book: book)
                    }
                }
            }
            .padding(.horizontal, 16)
        }
    }
}
