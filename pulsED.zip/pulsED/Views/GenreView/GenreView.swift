import SwiftUI

struct GenreView: View {
    var body: some View {
        NavigationView {
            Text("Genres")
                .navigationTitle("Genres")
        }
    }
}

struct GenreView_Previews: PreviewProvider {
    static var previews: some View {
        GenreView()
    }
}

