import SwiftUI

struct BookCard: View {
    let book: Book

    var body: some View {
        VStack {
            Image(book.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 150)
                .cornerRadius(8)
            Text(book.title)
                .font(.headline)
                .foregroundColor(.blue)
                .lineLimit(2)
                .frame(width: 100, height: 40, alignment: .center)
                .padding(.top, 8)
            Text(book.author)
                .font(.subheadline)
                .foregroundColor(.gray)
                .lineLimit(1)
                .frame(width: 100, height: 20, alignment: .center)
            // Commented out the bookmark button
            // Button(action: {
            //     if isBookmarked {
            //         bookmarkViewModel.removeBookmark(book: book)
            //     } else {
            //         bookmarkViewModel.addBookmark(book: book)
            //     }
            // }) {
            //     Image(systemName: isBookmarked ? "bookmark.fill" : "bookmark")
            //         .foregroundColor(isBookmarked ? .blue : .gray)
            //         .padding(.top, 8)
            // }
            ProgressView(value: book.progress)
                .progressViewStyle(LinearProgressViewStyle(tint: .green))
                .padding(.top, 8)
                .frame(width: 100)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.blue, lineWidth: 1)
        )
        .background(
            NavigationLink(destination: BookDetailView(book: book)) {
                EmptyView()
            }
            .opacity(0) // Make the navigation link invisible
        )
    }
}

