import SwiftUI
/*
struct BookContentView: View {
    let book: Book
    @EnvironmentObject var bookmarkManager: BookmarkManager
    @State private var currentPage = 0

    var body: some View {
        TabView(selection: $currentPage) {
            ForEach(0..<book.chapterSummaries.count, id: \.self) { index in
                PageView(title: book.chapterSummaries[index], content: "Content for \(book.chapterSummaries[index])")
                    .tag(index)
            }
            VStack {
                Image(book.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
                    .padding()
                Text("Rate and Purchase")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                Text("Rating the content will help other teachers find the top content. To find out more detailed information, consider buying the book.")
                    .padding()
                    .multilineTextAlignment(.center)
                Spacer()
                Link("Purchase Book", destination: URL(string: "https://www.amazon.com")!)
                    .padding()
                    .foregroundColor(.blue)
                Spacer()
                Text("Thank you for reading!")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                    .multilineTextAlignment(.center)
                Button(action: {
                    // Dismiss action
                }) {
                    Text("Go to Home")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(8)
                }
            }
            .tag(book.chapterSummaries.count)
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
        .onChange(of: currentPage) { newValue in
            let progress = Double(newValue + 1) / Double(book.chapterSummaries.count + 1)
            bookmarkManager.updateProgress(for: book, progress: progress)
        }
    }
}

struct PageView: View {
    let title: String
    let content: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title)
                .padding(.bottom)
            Text(content)
                .padding(.bottom)
            Spacer()
        }
        .padding()
    }
}

struct BookContentView_Previews: PreviewProvider {
    static var previews: some View {
        BookContentView(book: MocBook.mockBooks[0])
            .environmentObject(BookmarkManager())
    }
}

*/
