import SwiftUI
/*
struct BookContentView: View {
    let book: Book

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Content for \(book.title)")
                    .font(.title)
                    .padding()

                // Add your detailed book content here

                ForEach(book.chapterSummaries, id: \.self) { summary in
                    Text(summary)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                        .padding(.horizontal)
                        .padding(.bottom, 8)
                }
            }
            .padding(.vertical)
            .background(Color(UIColor.systemGroupedBackground))
        }
        .navigationBarTitle(Text(book.title), displayMode: .inline)
    }
}

*/
