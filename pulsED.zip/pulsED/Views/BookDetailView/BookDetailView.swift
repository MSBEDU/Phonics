import SwiftUI

struct BookDetailView: View {
    let book: Book

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                Image(book.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
                    .padding()
                
                Text(book.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.bottom, 2)
                
                Text("by \(book.author)")
                    .font(.title2)
                    .foregroundColor(.gray)
                    .padding(.bottom, 4)
                
                Text(book.description)
                    .padding(.bottom, 20)
                
                NavigationLink(destination: GenericBookContentView(book: book, totalPages: book.content.count)) {
                    Text("Start")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .padding(.bottom, 20)
                }
                
                Text("Content Sections")
                    .font(.headline)
                    .padding(.bottom, 10)
                
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(book.content) { content in
                        Text(content.title)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 2)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
        }
        .navigationBarTitle("Book Detail", displayMode: .inline)
    }
}

struct BookDetailView_Previews: PreviewProvider {
    static var previews: some View {
        BookDetailView(book: Book(
            id: UUID(),
            title: "Sample Book",
            author: "Sample Author",
            description: "This is a sample book description.",
            imageName: "sample_image",
            genres: ["Sample Genre"],
            progress: 0.0,
            content: [
                BookContent(title: "Sample Chapter 1", content: "Sample content for chapter 1."),
                BookContent(title: "Sample Chapter 2", content: "Sample content for chapter 2.")
            ]
        ))
    }
}

