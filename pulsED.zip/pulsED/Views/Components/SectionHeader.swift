//
//  SectionHeader.swift
//  pulsED
//
//  Created by Michael Bailey on 29/05/2024.
//

import Foundation
import Foundation
import SwiftUI

struct SectionHeader: View {
    let title: String

    var body: some View {
        Text(title)
            .font(.inter(size: 20))
            .foregroundColor(.navyBlue)
            .padding([.leading, .top], 16)
    }
}
