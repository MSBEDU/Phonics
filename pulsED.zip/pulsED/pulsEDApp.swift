import SwiftUI
import Combine
import Foundation

@main
struct pulsEDApp: App {
    @StateObject private var bookViewModel = BookViewModel()

    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(bookViewModel)
        }
    }
}

struct MainView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }

            Text("Bookmarked")
                .tabItem {
                    Image(systemName: "bookmark.fill")
                    Text("Bookmarked")
                }

            Text("Genres")
                .tabItem {
                    Image(systemName: "books.vertical.fill")
                    Text("Genres")
                }

            Text("Modules")
                .tabItem {
                    Image(systemName: "graduationcap.fill")
                    Text("Modules")
                }

            SearchView()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search")
                }
        }
    }
}

