import SwiftUI

struct ChapterSummariesView: View {
    let book: Book

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                ForEach(book.content) { chapter in
                    Text(chapter.title)
                        .font(.headline)
                        .padding(.top, 10)
                    Text(chapter.content)
                        .padding(.bottom, 10)
                }
            }
            .padding()
        }
        .navigationTitle("Chapter Summaries")
    }
}

struct ChapterSummariesView_Previews: PreviewProvider {
    static var previews: some View {
        ChapterSummariesView(book: Book(
            id: UUID(),
            title: "Visible Learning: A Synthesis of Over 800 Meta-Analyses Relating to Achievement",
            author: "John Hattie",
            description: "A book that synthesizes educational research to identify the most effective teaching strategies.",
            imageName: "JHvisiblelearning",
            genres: ["Educational Research", "Teaching Strategies"],
            progress: 0.6,
            content: [
                BookContent(title: "Introduction and the Visible Learning Story", content: "Content for Chapter 1"),
                BookContent(title: "The Source of the Ideas", content: "Content for Chapter 2"),
                BookContent(title: "The Power of Feedback", content: "Content for Chapter 3")
            ]
        ))
    }
}

