import SwiftUI

struct GenericBookContentView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var currentPage = 0
    let book: Book
    let totalPages: Int

    var body: some View {
        TabView(selection: $currentPage) {
            ForEach(book.content) { content in
                PageView(title: content.title, content: content.content)
                    .tag(book.content.firstIndex(where: { $0.id == content.id })!)
            }
            
            VStack {
                Image(book.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
                    .padding()
                Text("Rate and Purchase")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                Text("Rating the content will help other teachers find the top content. To find out more detailed information, consider buying the book.")
                    .padding()
                    .multilineTextAlignment(.center)
                Spacer()
                Link("Purchase Book", destination: URL(string: "https://www.amazon.com")!)
                    .padding()
                    .foregroundColor(.blue)
                Spacer()
                Text("Thank you for reading!")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                    .multilineTextAlignment(.center)
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Text("Go to Home")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(8)
                }
            }
            .tag(totalPages)
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
    }
}

struct PageView: View {
    let title: String
    let content: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title)
                .padding(.bottom)
            Text(content)
                .padding(.bottom)
            Spacer()
        }
        .padding()
    }
}

