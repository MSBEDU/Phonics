import SwiftUI
/*
struct Book2Content: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var bookmarkManager: BookmarkManager
    @State private var currentPage = 0
    let book: Book
    let totalPages = 13 // Updated to match the actual number of pages

    var body: some View {
        TabView(selection: $currentPage) {
            PageView(title: "Introduction and the Visible Learning Story", content: """
            John Hattie's "Visible Learning" begins by introducing the concept of visible learning, which focuses on evidence-based teaching strategies. Hattie synthesizes over 800 meta-analyses related to student achievement, emphasizing the importance of using evidence to guide educational practices. Teachers are encouraged to reflect on their methods and engage in professional development to stay informed about the latest research-based strategies.
            """)
            .tag(0)
            
            PageView(title: "The Source of the Ideas", content: """
            Hattie outlines the sources and methods used in his research, stressing the significance of meta-analyses in understanding what works in education. He advocates for utilizing educational research databases to find relevant studies and collaborating with colleagues to discuss and implement these findings. This approach helps educators make informed decisions about their teaching practices.
            """)
            .tag(1)
            
            PageView(title: "The Power of Feedback", content: """
            Feedback is a critical component of effective teaching, according to Hattie. He highlights that feedback should be timely, specific, and constructive to significantly impact student achievement. Teachers should provide regular, detailed feedback and encourage students to give peer feedback and reflect on the input they receive. This process helps students understand their progress and areas for improvement.
            """)
            .tag(2)
            
            PageView(title: "The Role of the Teacher", content: """
            Teachers play a crucial role in influencing student achievement. Hattie identifies characteristics of effective teachers, such as clarity, passion, and the ability to create a positive learning environment. Educators are advised to be explicit about learning objectives and success criteria, and to foster a supportive and engaging classroom atmosphere. These practices enhance students' learning experiences and outcomes.
            """)
            .tag(3)
            
            PageView(title: "The Importance of Learning Intentions and Success Criteria", content: """
            Setting clear learning intentions and success criteria is essential for guiding student learning. Hattie emphasizes that students should understand what they are expected to learn and how they will be assessed. Teachers should articulate learning goals at the beginning of each lesson and use success criteria to help students self-assess and peer-assess their work, promoting a deeper understanding of their learning objectives.
            """)
            .tag(4)
            
            PageView(title: "The Influence of Direct Instruction", content: """
            Direct instruction, when done effectively, is a highly impactful teaching method. Hattie explains that this approach involves clear teaching of skills and knowledge in a structured manner. Teachers should plan lessons that include explicit teaching, modeling, and guided practice, ensuring students understand the purpose and relevance of each lesson. This method helps students grasp complex concepts more effectively.
            """)
            .tag(5)
            
            PageView(title: "The Impact of Differentiated Instruction", content: """
            Differentiated instruction tailors teaching to meet the diverse needs of students. Hattie stresses the importance of knowing your students well and using assessment data to inform instructional planning. By providing varied learning activities that cater to different learning styles and abilities, teachers can help all students succeed. This personalized approach ensures that each student receives the support they need.
            """)
            .tag(6)
            
            PageView(title: "The Role of Assessment", content: """
            Effective assessment informs teaching and tracks student progress. Hattie discusses the use of both formative and summative assessments. Formative assessments should be used regularly to check for understanding and adjust teaching accordingly, while summative assessments should accurately reflect student learning. This balanced approach helps educators support student growth and achievement.
            """)
            .tag(7)
            
            PageView(title: "The Influence of the Home", content: """
            Hattie acknowledges the significant impact of parental involvement and the home environment on student achievement. Regular communication with parents about their child's progress and encouraging parental support for learning at home can enhance student outcomes. Strong home-school partnerships contribute to a more holistic approach to education.
            """)
            .tag(8)
            
            PageView(title: "The Power of Expectations", content: """
            High expectations from teachers can lead to higher student achievement. Hattie explains the Pygmalion effect, where higher expectations result in improved performance. Teachers should set high but achievable expectations for all students and communicate their belief in students' abilities to succeed. This positive reinforcement can motivate students to strive for excellence.
            """)
            .tag(9)
            
            PageView(title: "The Impact of Peer Influences", content: """
            Peer interactions can significantly affect learning. Hattie discusses strategies to foster positive peer influences, such as collaborative learning activities and teaching students how to give constructive feedback. By promoting a supportive peer culture, teachers can enhance students' social and academic development.
            """)
            .tag(10)
            
            PageView(title: "The Role of School Leadership", content: """
            Effective school leadership is vital for creating a supportive environment that promotes student learning. Hattie emphasizes the importance of instructional leadership, where school leaders focus on supporting teachers' professional growth and fostering a culture of continuous improvement. Positive school leadership can lead to better teaching practices and student outcomes.
            """)
            .tag(11)
            
            PageView(title: "The Impact of School Climate", content: """
            A positive school climate enhances student learning and well-being. Hattie identifies key factors that contribute to a positive climate, such as safety, inclusiveness, and strong relationships between students, teachers, and staff. Schools should promote a supportive environment where all members feel valued and respected, leading to improved student engagement and success.
            """)
            .tag(12)
            
            VStack {
                Image(book.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
                    .padding()
                Text("Rate and Purchase")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                Text("Rating the content will help other teachers find the top content. To find out more detailed information, consider buying the book.")
                    .padding()
                    .multilineTextAlignment(.center)
                Spacer()
                Link("Purchase Book", destination: URL(string: "https://www.amazon.com")!)
                    .padding()
                    .foregroundColor(.blue)
                Spacer()
                Text("Thank you for reading!")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                    .multilineTextAlignment(.center)
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Text("Go to Home")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(8)
                }
            }
            .tag(13)
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
    }
}



struct Book2Content_Previews: PreviewProvider {
    static var previews: some View {
        Book2Content(book: Book(id: UUID(), title: "Visible Learning: A Synthesis of Over 800 Meta-Analyses Relating to Achievement", author: "John Hattie", description: "A book that synthesizes educational research to identify the most effective teaching strategies.", imageName: "JHvisiblelearning", genres: ["Educational Research", "Teaching Strategies"], progress: 0.0, chapterSummaries: ["Introduction and the Visible Learning Story", "The Source of the Ideas", "The Power of Feedback", "The Role of the Teacher", "The Importance of Learning Intentions and Success Criteria", "The Influence of Direct Instruction", "The Impact of Differentiated Instruction", "The Role of Assessment", "The Influence of the Home", "The Power of Expectations", "The Impact of Peer Influences", "The Role of School Leadership", "The Impact of School Climate"]))
            .environmentObject(BookmarkManager())
    }
}
*/
