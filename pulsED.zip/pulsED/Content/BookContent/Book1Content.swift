import SwiftUI

/*
struct Book1Content: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var bookmarkManager: BookmarkManager
    @State private var currentPage = 0
    let book: Book
    let totalPages = 6 // Updated to match the actual number of pages

    var body: some View {
        TabView(selection: $currentPage) {
            PageView(title: "Character trumps Cognitive Skills", content: """
            In "How Children Succeed," Paul Tough emphasizes that character plays a significant role and character traits like grit and perseverance are imperative for success, sometimes more than even cognitive skills and intelligence. Grit is known as the sustaining effort and the passion that needs to be shown for long-term goals even after falling down or facing adversities. This has been popularized by the psychologist Angela Duckworth. Tough mentions that curiosity and optimism are other things that play a significant role in making a person explore and learn proactively.
            """)
            .tag(0)
            
            PageView(title: "Role of Adversity", content: """
            Tough discusses how early childhood adversity, namely poverty and neglect, can harmfully affect brain development, stress responses, and consequently have problematic effects on emotional and cognitive functions of the child. Still, children can be made resilient if they have the right support and interventions. This support includes supportive relationships, positive school environments, and programs that teach coping skills. That's the work, as Tough describes it, of researchers like Jack Shonkoff, who study how toxic stress has lifelong effects and how supportive interventions for such kids can diminish these effects to make the children succeed despite the early hardships.
            """)
            .tag(1)
            
            PageView(title: "Importance of Relationships", content: """
            Children get all the necessary grounds for emotional and social interactions in this world from their parents, teachers, and other mentors in their lives. Tough says that these kinds of relationships are the only things that have the capacity to buffer the ill effects that stress has on children's minds. He uses attachment theory, developed by John Bowlby and Mary Ainsworth, which has said that secure attachments in early childhood result in better emotional regulation and social skills. Tough gives specific examples of mentoring programs and interventions that build on these attachments, showing that such attachments are essential in guiding children to success.
            """)
            .tag(2)
            
            PageView(title: "Non-Cognitive Skills in School", content: """
            Tough points out several school-based interventions or programs that target these non-cognitive skills, including self-control, social intelligence, and gratitude, in addition to those concerned with academic skills. Programs like the KIPP (Knowledge Is Power Program) schools and Tools of the Mind focus on students' character and executive function skills. The programs help students acquire and master the non-cognitive skills that enable them to excel in both academic and life situations. Tough claims that such character education increases the school performance levels of students because non-cognitive skills are the essential ingredients in handling all of life's difficulties.
            """)
            .tag(3)
            
            PageView(title: "Evidence and Research", content: """
            Paul Tough uses an enormous amount of research in psychology, neuroscience, and education to back his claims. He relies on the work of such researchers as Angela Duckworth, who studies grit; James Heckman, an economist who shows the relevance of non-cognitive skills in economic success; and Jack Shonkoff, who examines the effects of early adversity on child development. The studies collectively suggest that character can be produced and that character produces long term success. Tough himself gives much evidence in the form of case studies of students who have overcome much through character development, showing the power of the production of character in becoming successful.
            """)
            .tag(4)
            
            PageView(title: "Conclusion", content: """
            Paul Tough, in "How Children Succeed", moves from traditional indicators of academic success to those of character that impact children and determine the outcome of life's trials. To learn more about Tough's work, which focuses on grit, curiosity, and supportive relationships, read his book: a comprehensive view of what goes to the very core of a child's success. A road map to shaping educational programs and support systems to develop those all-important non-cognitive skills, which allow kids to achieve the great things against all the odds. Read more about these findings in the book, which is available at Amazon.
            """)
            .tag(5)
            
            VStack {
                Image(book.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
                    .padding()
                Text("Rate and Purchase")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                Text("Rating the content will help other teachers find the top content. To find out more detailed information, consider buying the book.")
                    .padding()
                    .multilineTextAlignment(.center)
                Spacer()
                Link("Purchase Book", destination: URL(string: "https://www.amazon.com")!)
                    .padding()
                    .foregroundColor(.blue)
                Spacer()
                Text("Thank you for reading!")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                    .multilineTextAlignment(.center)
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Text("Go to Home")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(8)
                }
            }
            .tag(6)
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
    }
}


struct Book1Content_Previews: PreviewProvider {
    static var previews: some View {
        Book1Content(
            book: Book(
                id: UUID(),
                title: "How Children Succeed: Grit, Curiosity, and the Hidden Power of Character",
                author: "Paul Tough",
                description: "A book that investigates the factors that contribute to a child's success, emphasizing the importance of character.",
                imageName: "PaulTough",
                genres: ["Character Education", "Motivation"],
                progress: 0.0,
                content: [
                    BookContent(title: "Character trumps Cognitive Skills", content: """
                    In "How Children Succeed," Paul Tough emphasizes that character plays a significant role and character traits like grit and perseverance are imperative for success, sometimes more than even cognitive skills and intelligence. Grit is known as the sustaining effort and the passion that needs to be shown for long-term goals even after falling down or facing adversities. This has been popularized by the psychologist Angela Duckworth. Tough mentions that curiosity and optimism are other things that play a significant role in making a person explore and learn proactively.
                    """),
                    BookContent(title: "Role of Adversity", content: """
                    Tough discusses how early childhood adversity, namely poverty and neglect, can harmfully affect brain development, stress responses, and consequently have problematic effects on emotional and cognitive functions of the child. Still, children can be made resilient if they have the right support and interventions. This support includes supportive relationships, positive school environments, and programs that teach coping skills. That's the work, as Tough describes it, of researchers like Jack Shonkoff, who study how toxic stress has lifelong effects and how supportive interventions for such kids can diminish these effects to make the children succeed despite the early hardships.
                    """),
                    BookContent(title: "Importance of Relationships", content: """
                    Children get all the necessary grounds for emotional and social interactions in this world from their parents, teachers, and other mentors in their lives. Tough says that these kinds of relationships are the only things that have the capacity to buffer the ill effects that stress has on children's minds. He uses attachment theory, developed by John Bowlby and Mary Ainsworth, which has said that secure attachments in early childhood result in better emotional regulation and social skills. Tough gives specific examples of mentoring programs and interventions that build on these attachments, showing that such attachments are essential in guiding children to success.
                    """),
                    BookContent(title: "Non-Cognitive Skills in School", content: """
                    Tough points out several school-based interventions or programs that target these non-cognitive skills, including self-control, social intelligence, and gratitude, in addition to those concerned with academic skills. Programs like the KIPP (Knowledge Is Power Program) schools and Tools of the Mind focus on students' character and executive function skills. The programs help students acquire and master the non-cognitive skills that enable them to excel in both academic and life situations. Tough claims that such character education increases the school performance levels of students because non-cognitive skills are the essential ingredients in handling all of life's difficulties.
                    """),
                    BookContent(title: "Evidence and Research", content: """
                    Paul Tough uses an enormous amount of research in psychology, neuroscience, and education to back his claims. He relies on the work of such researchers as Angela Duckworth, who studies grit; James Heckman, an economist who shows the relevance of non-cognitive skills in economic success; and Jack Shonkoff, who examines the effects of early adversity on child development. The studies collectively suggest that character can be produced and that character produces long term success. Tough himself gives much evidence in the form of case studies of students who have overcome much through character development, showing the power of the production of character in becoming successful.
                    """),
                    BookContent(title: "Conclusion", content: """
                    Paul Tough, in "How Children Succeed", moves from traditional indicators of academic success to those of character that impact children and determine the outcome of life's trials. To learn more about Tough's work, which focuses on grit, curiosity, and supportive relationships, read his book: a comprehensive view of what goes to the very core of a child's success. A road map to shaping educational programs and support systems to develop those all-important non-cognitive skills, which allow kids to achieve the great things against all the odds. Read more about these findings in the book, which is available at Amazon.
                    """)
                ]
            )
        )
        .environmentObject(BookmarkManager())
    }
}
 */
