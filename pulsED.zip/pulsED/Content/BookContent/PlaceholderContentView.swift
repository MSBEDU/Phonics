import SwiftUI

struct PlaceholderContentView: View {
    let book: Book

    var body: some View {
        VStack {
            Text("Content for \(book.title)")
                .font(.largeTitle)
                .padding()
            
            ScrollView {
                VStack(alignment: .leading) {
                    ForEach(book.content) { content in
                        Text(content.title)
                            .font(.headline)
                            .padding(.top, 10)
                        Text(content.content)
                            .padding(.bottom, 10)
                    }
                }
                .padding()
            }
        }
        .navigationBarTitle(Text(book.title), displayMode: .inline)
    }
}

struct PlaceholderContentView_Previews: PreviewProvider {
    static var previews: some View {
        PlaceholderContentView(book: Book(
            id: UUID(),
            title: "Visible Learning: A Synthesis of Over 800 Meta-Analyses Relating to Achievement",
            author: "John Hattie",
            description: "A book that synthesizes educational research to identify the most effective teaching strategies.",
            imageName: "JHvisiblelearning",
            genres: ["Educational Research", "Teaching Strategies"],
            progress: 0.6,
            content: [
                BookContent(title: "Introduction and the Visible Learning Story", content: "Content for Chapter 1"),
                BookContent(title: "The Source of the Ideas", content: "Content for Chapter 2"),
                BookContent(title: "The Power of Feedback", content: "Content for Chapter 3")
            ]
        ))
    }
}

